const originalFetch = global.fetch;

global.fetch = async (input, init) => {
  const requestUrl = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
  const url = new URL(requestUrl);
  if (url.origin !== 'https://oauth2.googleapis.com' || url.pathname !== '/tokeninfo') {
    return originalFetch(input, init);
  }

  const credential = url.searchParams.get('id_token');
  if (credential !== 'verified-google-token' && credential !== 'wrong-audience-google-token') {
    return new Response(JSON.stringify({ error: 'invalid_token' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const profile = {
    aud: credential === 'wrong-audience-google-token' ? 'another-google-client-id' : process.env.GOOGLE_CLIENT_ID,
    sub: 'test-google-user-1',
    name: 'Google Test User',
    email: 'google-otp-user@example.test',
  };
  return new Response(JSON.stringify(profile), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  });
};