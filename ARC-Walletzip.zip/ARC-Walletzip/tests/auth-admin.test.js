const assert = require('node:assert/strict');
const { spawn, spawnSync } = require('node:child_process');
const { once } = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const vm = require('node:vm');
const { DatabaseSync } = require('node:sqlite');
const { after, before, describe, it } = require('node:test');

const root = path.resolve(__dirname, '..');
const adminEmail = 'test-admin@example.test';
const adminPassword = 'test-admin-password-2026';
const userEmail = 'new-wallet-user@example.test';
const userPassword = 'test-user-password-2026';
const testEnv = {
  ...process.env,
  NODE_ENV: 'test',
  DATABASE_PATH: '',
  ADMIN_EMAIL: adminEmail,
  ADMIN_PASSWORD: adminPassword,
  ALLOW_DEV_OTP: 'true',
  JWT_SECRET: 'isolated-test-session-secret',
  GOOGLE_CLIENT_ID: 'google-test-client-id',
  NODE_OPTIONS: [process.env.NODE_OPTIONS, `--require=${path.join(__dirname, 'google-tokeninfo-mock.js')}`].filter(Boolean).join(' '),
};

let tempDir;
let databasePath;
let serverProcess;
let baseUrl;
let stdout = '';
let stderr = '';
let userToken;

const delay = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

const getFreePort = async () => {
  const listener = net.createServer();
  listener.listen(0, '127.0.0.1');
  await once(listener, 'listening');
  const { port } = listener.address();
  await new Promise((resolve, reject) => listener.close((error) => error ? reject(error) : resolve()));
  return port;
};

const startServer = async () => {
  const port = await getFreePort();
  baseUrl = `http://127.0.0.1:${port}`;
  serverProcess = spawn(process.execPath, [path.join(root, 'server.js')], {
    cwd: root,
    env: { ...testEnv, PORT: String(port), DATABASE_PATH: databasePath },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  stdout = '';
  stderr = '';
  serverProcess.stdout.setEncoding('utf8').on('data', (chunk) => { stdout += chunk; });
  serverProcess.stderr.setEncoding('utf8').on('data', (chunk) => { stderr += chunk; });

  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    if (serverProcess.exitCode !== null) {
      throw new Error(`Server exited before becoming ready.\n${stdout}\n${stderr}`);
    }
    try {
      const response = await fetch(`${baseUrl}/api/health`);
      if (response.ok) return;
    } catch {}
    await delay(100);
  }
  throw new Error(`Server did not become ready.\n${stdout}\n${stderr}`);
};

const stopServer = async () => {
  if (!serverProcess || serverProcess.exitCode !== null) return;
  const child = serverProcess;
  const exited = once(child, 'exit');
  child.kill('SIGTERM');
  await Promise.race([exited, delay(3000)]);
  if (child.exitCode === null) {
    child.kill('SIGKILL');
    await exited;
  }
  serverProcess = undefined;
};

const request = async (pathname, { method = 'GET', token, body } = {}) => {
  const hasBody = body !== undefined;
  const response = await fetch(`${baseUrl}${pathname}`, {
    method,
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
    },
    ...(hasBody ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json();
  return { status: response.status, data };
};

const createWalletUiHarness = (mockWallet = {}) => {
  const elements = new Map();
  const apiCalls = [];
  const pendingRequests = new Set();
  const session = new Map();

  class MockElement {
    constructor(id = '') {
      this.id = id;
      this.textContent = '';
      this._innerHTML = '';
      this.value = '';
      this.disabled = false;
      this.style = {};
      this.dataset = {};
      this.listeners = new Map();
      this.classes = new Set();
      this.classList = {
        add: (...names) => names.forEach((name) => this.classes.add(name)),
        remove: (...names) => names.forEach((name) => this.classes.delete(name)),
        contains: (name) => this.classes.has(name),
        toggle: (name, force = !this.classes.has(name)) => {
          if (force) this.classes.add(name);
          else this.classes.delete(name);
          return force;
        },
      };
    }

    get innerHTML() { return this._innerHTML; }
    set innerHTML(markup) {
      this._innerHTML = String(markup);
      for (const [, id] of this._innerHTML.matchAll(/\bid="([^"]+)"/g)) {
        const element = ensureElement(id);
        const selectMarkup = new RegExp(`<select\\b[^>]*\\bid="${id}"[^>]*>([\\s\\S]*?)<\\/select>`).exec(this._innerHTML);
        if (selectMarkup && !element.value) {
          element.value = /<option\b[^>]*value="([^"]+)"/.exec(selectMarkup[1])?.[1] || '';
        }
      }
    }

    addEventListener(type, listener) { this.listeners.set(type, listener); }
    querySelector(selector) {
      const childKey = `${this.id}:${selector}`;
      if (!elements.has(childKey)) elements.set(childKey, new MockElement(childKey));
      return elements.get(childKey);
    }
    dispatch(type, extra = {}) {
      const listener = this.listeners.get(type);
      if (!listener) throw new Error(`No ${type} listener is registered for ${this.id}.`);
      return listener({ preventDefault() {}, target: this, currentTarget: this, ...extra });
    }
  }

  const ensureElement = (id) => {
    if (!elements.has(id)) elements.set(id, new MockElement(id));
    return elements.get(id);
  };

  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  for (const [, id] of html.matchAll(/\bid="([^"]+)"/g)) ensureElement(id);
  ensureElement('authView').classList.add('hidden');
  ensureElement('walletView').classList.add('hidden');
  ensureElement('password').nextElementSibling = ensureElement('passwordToggle');

  const selectors = new Map([
    ['.wallet-header h1', ensureElement('walletHeading')],
    ['.social-stack', ensureElement('socialStack')],
    ['.select-all input', ensureElement('selectAllNetworks')],
  ]);
  const document = {
    title: 'ARC Wallet',
    head: { appendChild() {} },
    getElementById: ensureElement,
    querySelector: (selector) => selectors.get(selector) || ensureElement(`selector:${selector}`),
    querySelectorAll: () => [],
  };
  const location = { protocol: 'http:', origin: baseUrl, search: '', pathname: '/' };
  const window = { location, history: { replaceState() {} } };
  const navigator = {};
  const sessionStorage = {
    getItem: (key) => session.has(key) ? session.get(key) : null,
    setItem: (key, value) => session.set(key, String(value)),
    removeItem: (key) => session.delete(key),
  };

  const trackedFetch = (input, options = {}) => {
    const url = new URL(input, baseUrl);
    const method = options.method || 'GET';
    apiCalls.push({ pathname: url.pathname, method });
    const mockedResponse = (payload) => Promise.resolve({ ok: true, json: async () => payload });
    const result = url.pathname === '/api/config'
      ? Promise.resolve({ ok: true, json: async () => ({ providers: {}, googleClientId: null, sharedDepositPairs: [{ asset: 'ETH', network: 'Ethereum Mainnet' }, { asset: 'BTC', network: 'Bitcoin' }] }) })
      : url.pathname === '/api/market'
        ? Promise.resolve({ ok: true, json: async () => ({ quotes: {}, source: 'Unavailable', updatedAt: new Date().toISOString() }) })
        : url.pathname === '/api/wallet' && mockWallet.wallet
          ? mockedResponse(mockWallet.wallet)
          : url.pathname === '/api/wallet/capabilities' && mockWallet.capabilities
            ? mockedResponse(mockWallet.capabilities)
            : url.pathname.startsWith('/api/wallet/receive/') && mockWallet.receiveAddresses
              ? (() => {
                const asset = decodeURIComponent(url.pathname.slice('/api/wallet/receive/'.length));
                const network = url.searchParams.get('network');
                const address = mockWallet.receiveAddresses[`${asset}:${network}`];
                return mockedResponse(address
                  ? { verified: true, provider: 'Test Custody', asset, network, address }
                  : { verified: false, asset, network });
              })()
              : url.pathname === '/api/wallet/balance' && mockWallet.balance
                ? mockedResponse(mockWallet.balance)
        : fetch(url, options);
    const tracked = Promise.resolve(result);
    pendingRequests.add(tracked);
    tracked.then(() => pendingRequests.delete(tracked), () => pendingRequests.delete(tracked));
    return tracked;
  };
  const context = {
    window,
    document,
    navigator,
    sessionStorage,
    fetch: trackedFetch,
    URL,
    URLSearchParams,
    setInterval: () => 1,
    clearInterval() {},
    setTimeout: () => 1,
    console,
  };
  const appSource = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
  vm.runInNewContext(`${appSource}\nglobalThis.__walletTestHooks = { completeLogin, loadWallet };`, context, { filename: 'app.js' });

  const waitForRequests = async () => {
    for (let attempt = 0; attempt < 30; attempt += 1) {
      const activeRequests = [...pendingRequests];
      if (activeRequests.length) await Promise.allSettled(activeRequests);
      else {
        await new Promise((resolve) => setImmediate(resolve));
        if (!pendingRequests.size) return;
      }
    }
    throw new Error('Wallet UI requests did not settle.');
  };

  return { elements, apiCalls, sessionStorage, waitForRequests, hooks: context.__walletTestHooks };
};

const registerWithTestOtp = async (email) => {
  const registration = await request('/auth/register', {
    method: 'POST',
    body: { email, password: userPassword },
  });
  assert.equal(registration.status, 200);
  assert.equal(registration.data.requiresOtp, true);
  assert.equal(registration.data.mailConfigured, false);
  assert.match(registration.data.devCode, /^\d{6}$/);
  return registration.data;
};

const loginAdmin = async () => {
  const login = await request('/admin/login', {
    method: 'POST',
    body: { identifier: 'arcwallet@admin', password: adminPassword },
  });
  assert.equal(login.status, 200);
  return login.data.token;
};

describe('registration, wallet, and admin access', () => {
  before(async () => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'arc-wallet-auth-tests-'));
    databasePath = path.join(tempDir, 'test.sqlite');

    // Initialize only the schema, then provision the test admin with the real setup script.
    await startServer();
    await stopServer();
    const setup = spawnSync(process.execPath, [path.join(root, 'scripts/setup-admin.js')], {
      cwd: root,
      env: { ...testEnv, DATABASE_PATH: databasePath },
      encoding: 'utf8',
    });
    assert.equal(setup.status, 0, `Admin setup failed.\n${setup.stdout}\n${setup.stderr}`);
    const database = new DatabaseSync(databasePath);

    const admin = database.prepare('SELECT id, role, status FROM users WHERE lower(email) = ?').get(adminEmail);
    database.prepare('INSERT INTO transactions (id, user_name, pair, amount, status, date) VALUES (?, ?, ?, ?, ?, ?)').run(
      'TX-ADMIN-AUTH-TEST',
      'Test User',
      'USDC - BTC',
      '25 USDC',
      'Pending',
      '2026-09-25',
    );
    database.close();
    await startServer();
  });

  after(async () => {
    await stopServer();
    if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
  });

  it('blocks unauthenticated wallet and admin route access', async () => {
    assert.equal((await request('/api/wallet')).status, 401);
    for (const pathname of ['/api/admin/overview', '/api/admin/users', '/api/admin/requests', '/api/admin/transactions']) {
      assert.equal((await request(pathname)).status, 401, `${pathname} must require an admin session`);
    }
    assert.equal((await request('/api/admin/settings', {
      method: 'PATCH',
      body: { maintenance: true, defaultNetwork: 'Unauthorized', supportEmail: 'bad@example.test' },
    })).status, 401);
    assert.equal((await request('/api/admin/transactions/unknown', {
      method: 'PATCH',
      body: { status: 'Success' },
    })).status, 401);

    const publicPage = await fetch(`${baseUrl}/`);
    const publicHtml = await publicPage.text();
    assert.doesNotMatch(publicHtml, /Admin panel|admin\.html/i);
    assert.equal((await fetch(`${baseUrl}/admin.html`)).status, 404);
    const hiddenAdminRoute = await fetch(`${baseUrl}/admin`);
    const registration = await registerWithTestOtp(userEmail);

    const incorrectCode = registration.devCode === '999999' ? '000000' : '999999';
    const wrongCode = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: registration.challengeId, code: incorrectCode },
    });
    assert.equal(wrongCode.status, 401);

    const verification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: registration.challengeId, code: registration.devCode },
    });
    assert.equal(verification.status, 200);
    assert.equal(verification.data.user.email, userEmail);
    assert.equal(verification.data.user.status, 'Pending');
    assert.equal(verification.data.pendingApproval, true);
    assert.equal(verification.data.token, undefined);

    const blockedLogin = await request('/auth/login', { method: 'POST', body: { email: userEmail, password: userPassword } });
    assert.equal(blockedLogin.status, 403);
    assert.match(blockedLogin.data.error, /pending admin approval/i);

    const reusedCode = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: registration.challengeId, code: registration.devCode },
    });
    assert.equal(reusedCode.status, 401);
    assert.equal(reusedCode.data.token, undefined);

    const adminToken = await loginAdmin();
    const approval = await request(`/api/admin/users/${encodeURIComponent(verification.data.user.id)}/approve`, { method: 'POST', token: adminToken });
    assert.equal(approval.status, 200);
    assert.equal(approval.data.status, 'Active');
    const login = await request('/auth/login', { method: 'POST', body: { email: userEmail, password: userPassword } });
    assert.equal(login.status, 200);
    const activeVerification = await request('/auth/verify-otp', { method: 'POST', body: { challengeId: login.data.challengeId, code: login.data.devCode } });
    assert.equal(activeVerification.status, 200);
    assert.equal(activeVerification.data.user.status, 'Active');
    userToken = activeVerification.data.token;

    const wallet = await request('/api/wallet', { token: userToken });
    assert.equal(wallet.status, 200);
    assert.equal(wallet.data.user.email, userEmail);
    assert.equal(wallet.data.user.role, 'User');
    assert.equal(wallet.data.walletMode, 'demo');
    assert.equal(wallet.data.balance, null);
    assert.equal(wallet.data.address, null);
    assert.deepEqual(wallet.data.transactions, []);

    const sharedConfig = await request('/api/config');
    assert.deepEqual(sharedConfig.data.sharedDepositPairs, [
      { asset: 'ETH', network: 'Ethereum Mainnet' },
      { asset: 'BTC', network: 'Bitcoin' },
    ]);
    assert.equal(JSON.stringify(sharedConfig.data).includes('0x45fa3421948a8a0372e0a172ab9a3725f785a1d2'), false);
    assert.equal(JSON.stringify(sharedConfig.data).includes('17v1CRcS2JbZhYy24g7mJRth8uz1Um4QFq'), false);
    assert.equal((await request('/api/wallet/receive/ETH?network=Ethereum%20Mainnet&shared=true')).status, 401);
    const sharedEth = await request('/api/wallet/receive/ETH?network=Ethereum%20Mainnet&shared=true', { token: userToken });
    assert.equal(sharedEth.status, 200);
    assert.deepEqual(sharedEth.data, {
      verified: false,
      shared: true,
      asset: 'ETH',
      network: 'Ethereum Mainnet',
      address: '0x45fa3421948a8a0372e0a172ab9a3725f785a1d2',
    });
    const sharedBtc = await request('/api/wallet/receive/BTC?network=Bitcoin&shared=true', { token: userToken });
    assert.equal(sharedBtc.status, 200);
    assert.equal(sharedBtc.data.address, '17v1CRcS2JbZhYy24g7mJRth8uz1Um4QFq');
    assert.equal((await request('/api/wallet/receive/ETH?network=Arbitrum&shared=true', { token: userToken })).status, 404);

    const receiveAddress = await request('/api/wallet/receive/USDC', { token: userToken });
    assert.equal(receiveAddress.status, 503);
    assert.match(receiveAddress.data.error, /no verified wallet provider/i);
    assert.equal((await request('/api/wallet/receive/ETH?network=Ethereum%20Mainnet', { token: userToken })).status, 503);
    assert.equal((await request('/api/wallet/receive/not-an-asset', { token: userToken })).status, 400);

    const unverifiedTransaction = await request('/api/wallet/transactions', {
      method: 'POST',
      token: userToken,
      body: { symbol: 'USDC', amount: 12.5, txHash: '0xTEST1234567890' },
    });
    assert.equal(unverifiedTransaction.status, 503);
    assert.match(unverifiedTransaction.data.error, /confirms on-chain status/i);
    assert.deepEqual((await request('/api/wallet', { token: userToken })).data.transactions, []);

    const claim = await request('/api/wallet/deposit-requests', {
      method: 'POST',
      token: userToken,
      body: { asset: 'ETH', network: 'Ethereum Mainnet', amount: '0.25', txHash: `0x${'b'.repeat(64)}` },
    });
    assert.equal(claim.status, 201);
    assert.equal(claim.data.status, 'Pending');
    assert.equal((await request('/api/wallet', { token: userToken })).data.internalBalances.ETH, undefined);
    assert.equal((await request(`/api/admin/requests/${claim.data.id}/review`, { method: 'POST', token: await loginAdmin(), body: { decision: 'reject' } })).status, 200);
  });

  it('keeps the signed-in demo wallet free of fake funds and transaction activity', async () => {
    const wallet = await request('/api/wallet', { token: userToken });
    assert.equal(wallet.data.walletMode, 'demo');

    const ui = createWalletUiHarness();
    ui.hooks.completeLogin({
      token: userToken,
      user: { name: wallet.data.user.name, email: wallet.data.user.email },
    });
    await ui.waitForRequests();

    assert.equal(ui.elements.get('authView').classList.contains('hidden'), true);
    assert.equal(ui.elements.get('walletView').classList.contains('hidden'), false);
    assert.equal(ui.elements.get('walletBalanceValue').textContent, '—');
    assert.equal(ui.elements.get('walletBalanceAsset').textContent, 'ETH');
    assert.equal(ui.elements.get('walletAddress').textContent, 'No deposit address');
    assert.match(ui.elements.get('providerNotice:strong').textContent, /unavailable/i);
    assert.match(ui.elements.get('exchangeGrid').innerHTML, /No wallet activity is available/);

    await ui.elements.get('openSend').dispatch('click');
    assert.match(ui.elements.get('actionTitle').textContent, /Request withdrawal/i);
    assert.match(ui.elements.get('actionBody').innerHTML, /stays pending until admin review/i);
    assert.match(ui.elements.get('actionBody').innerHTML, /No on-chain transfer is sent/i);

    await ui.elements.get('openReceive').dispatch('click');
    assert.match(ui.elements.get('actionTitle').textContent, /Receive or report a deposit/i);
    assert.match(ui.elements.get('actionBody').innerHTML, /Show shared address/);
    assert.match(ui.elements.get('actionBody').innerHTML, /depositClaimButton/);
    assert.equal(ui.elements.get('showSharedDepositAddress').classList.contains('hidden'), false);
    assert.equal(ui.elements.get('walletAddress').textContent, 'No deposit address');
    assert.equal(ui.apiCalls.some(({ pathname }) => pathname.startsWith('/api/wallet/receive/')), false);
    await ui.elements.get('showSharedDepositAddress').dispatch('click');
    await ui.waitForRequests();
    assert.equal(ui.elements.get('receiveAddress').textContent, '0x45fa3421948a8a0372e0a172ab9a3725f785a1d2');
    assert.match(ui.elements.get('receiveInstructions').textContent, /shared.*not an account-specific address/i);
    assert.match(ui.elements.get('receiveInstructions').textContent, /admin review/i);
    assert.match(ui.elements.get('walletAddress').textContent, /^Shared:/);
    ui.elements.get('receiveAsset').value = 'BTC';
    await ui.elements.get('receiveAsset').dispatch('change');
    assert.equal(ui.elements.get('receiveNetwork').value, 'Bitcoin');
    assert.equal(ui.elements.get('showSharedDepositAddress').classList.contains('hidden'), false);
    await ui.elements.get('showSharedDepositAddress').dispatch('click');
    await ui.waitForRequests();
    assert.equal(ui.elements.get('receiveAddress').textContent, '17v1CRcS2JbZhYy24g7mJRth8uz1Um4QFq');
    assert.match(ui.elements.get('receiveInstructions').textContent, /shared BTC address/i);

    await ui.elements.get('openExchange').dispatch('click');
    assert.match(ui.elements.get('actionBody').innerHTML, /No trade will be submitted or executed/i);
    ui.elements.get('exchangeAmount').value = '12.5';
    await ui.elements.get('exchangeForm').dispatch('submit');
    assert.match(ui.elements.get('exchangeNote').textContent, /No trade was executed/i);
    assert.equal(ui.apiCalls.some(({ pathname }) => pathname.startsWith('/api/wallet/receive/')), true);
    assert.equal(ui.apiCalls.some(({ pathname, method }) => pathname === '/api/wallet/transactions' && method === 'POST'), false);
  });

  it('shows only verified custody pairs in wallet selectors and blocks unsupported UI submissions', async () => {
    const ui = createWalletUiHarness({
      wallet: {
        walletMode: 'provider',
        user: { id: 'provider-user', name: 'Provider User', email: 'provider@example.test' },
        transactions: [],
        internalBalances: {},
        requests: [],
      },
      capabilities: {
        verified: true,
        provider: 'Test Custody',
        pairs: [{ asset: 'BTC', network: 'Bitcoin' }],
      },
      balance: { verified: true, asset: 'BTC', network: 'Bitcoin', balance: '0' },
    });
    ui.hooks.completeLogin({ token: 'provider-test-token', user: { name: 'Provider User', email: 'provider@example.test' } });
    await ui.waitForRequests();
    assert.equal(ui.elements.get('openAssets').textContent, '◉ BTC');
    assert.match(ui.elements.get('openNetwork').innerHTML, /Bitcoin/);

    await ui.elements.get('openAssets').dispatch('click');
    assert.match(ui.elements.get('actionBody').innerHTML, /<option value="BTC">/);
    assert.doesNotMatch(ui.elements.get('actionBody').innerHTML, /<option value="ETH">/);
    await ui.elements.get('openNetwork').dispatch('click');
    assert.match(ui.elements.get('actionBody').innerHTML, /<option value="Bitcoin">Bitcoin<\/option>/);
    assert.doesNotMatch(ui.elements.get('actionBody').innerHTML, /Arbitrum|Ethereum Mainnet/);

    await ui.elements.get('openReceive').dispatch('click');
    assert.match(ui.elements.get('actionBody').innerHTML, /<option value="BTC">/);
    assert.doesNotMatch(ui.elements.get('actionBody').innerHTML, /<option value="ETH">/);
    assert.match(ui.elements.get('receiveNetwork').innerHTML, /<option value="Bitcoin">Bitcoin<\/option>/);
    ui.elements.get('receiveAsset').value = 'ETH';
    ui.elements.get('receiveNetwork').value = 'Arbitrum';
    await ui.elements.get('receiveForm').dispatch('submit');
    assert.equal(ui.apiCalls.some(({ pathname }) => pathname.startsWith('/api/wallet/receive/')), false);
  });

  it('clears a provider-verified address when the selected asset or network changes', async () => {
    const addresses = {
      'ETH:Ethereum Mainnet': '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
      'ETH:Arbitrum': '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',
      'BTC:Bitcoin': '1Ccccccccccccccccccccccccccccccccc',
    };
    const ui = createWalletUiHarness({
      wallet: {
        walletMode: 'provider',
        user: { id: 'provider-user', name: 'Provider User', email: 'provider@example.test' },
        transactions: [],
        internalBalances: {},
        requests: [],
      },
      capabilities: {
        verified: true,
        provider: 'Test Custody',
        pairs: [
          { asset: 'ETH', network: 'Ethereum Mainnet' },
          { asset: 'ETH', network: 'Arbitrum' },
          { asset: 'BTC', network: 'Bitcoin' },
        ],
      },
      balance: { verified: true, asset: 'ETH', network: 'Ethereum Mainnet', balance: '0' },
      receiveAddresses: addresses,
    });
    ui.hooks.completeLogin({ token: 'provider-test-token', user: { name: 'Provider User', email: 'provider@example.test' } });
    await ui.waitForRequests();
    await ui.elements.get('openReceive').dispatch('click');
    await ui.elements.get('receiveForm').dispatch('submit');
    await ui.waitForRequests();

    assert.equal(ui.elements.get('receiveAddressPanel').classList.contains('hidden'), false);
    assert.equal(ui.elements.get('receiveAddress').textContent, addresses['ETH:Ethereum Mainnet']);

    ui.elements.get('receiveNetwork').value = 'Arbitrum';
    await ui.elements.get('receiveNetwork').dispatch('change');
    assert.equal(ui.elements.get('receiveAddressPanel').classList.contains('hidden'), true);
    assert.equal(ui.elements.get('receiveAddress').textContent, '');
    assert.equal(ui.elements.get('walletAddress').textContent, 'No deposit address');

    await ui.elements.get('receiveForm').dispatch('submit');
    await ui.waitForRequests();
    assert.equal(ui.elements.get('receiveAddressPanel').classList.contains('hidden'), false);
    assert.equal(ui.elements.get('receiveAddress').textContent, addresses['ETH:Arbitrum']);

    ui.elements.get('receiveAsset').value = 'BTC';
    await ui.elements.get('receiveAsset').dispatch('change');
    assert.equal(ui.elements.get('receiveNetwork').value, 'Bitcoin');
    assert.equal(ui.elements.get('receiveAddressPanel').classList.contains('hidden'), true);
    assert.equal(ui.elements.get('receiveAddress').textContent, '');
    assert.equal(ui.elements.get('walletAddress').textContent, 'No deposit address');

    await ui.elements.get('receiveForm').dispatch('submit');
    await ui.waitForRequests();
    assert.equal(ui.elements.get('receiveAddressPanel').classList.contains('hidden'), false);
    assert.equal(ui.elements.get('receiveAddress').textContent, addresses['BTC:Bitcoin']);
  });

  for (const { description, balance } of [
    {
      description: 'unverified custody balances',
      balance: { verified: false, asset: 'BTC', network: 'Bitcoin', balance: '12.5' },
    },
    {
      description: 'verified balances for a different asset',
      balance: { verified: true, asset: 'ETH', network: 'Bitcoin', balance: '12.5' },
    },
    {
      description: 'verified balances for a different network',
      balance: { verified: true, asset: 'BTC', network: 'Ethereum Mainnet', balance: '12.5' },
    },
  ]) {
    it(`keeps the provider wallet unavailable for ${description}`, async () => {
      const ui = createWalletUiHarness({
        wallet: {
          walletMode: 'provider',
          user: { id: 'provider-user', name: 'Provider User', email: 'provider@example.test' },
          transactions: [],
          internalBalances: {},
          requests: [],
        },
        capabilities: {
          verified: true,
          provider: 'Test Custody',
          pairs: [{ asset: 'BTC', network: 'Bitcoin' }],
        },
        balance,
      });
      ui.hooks.completeLogin({ token: 'provider-test-token', user: { name: 'Provider User', email: 'provider@example.test' } });
      await ui.waitForRequests();

      assert.equal(ui.elements.get('walletBalanceValue').textContent, '—');
      assert.equal(ui.elements.get('walletBalanceAsset').textContent, 'BTC');
      assert.match(ui.elements.get('providerNotice:strong').textContent, /unavailable/i);
      assert.match(ui.elements.get('providerNotice:span').textContent, /did not verify/i);
    });
  }

  it('records admin balance adjustments and preserves account history when a user is deleted or restored', async () => {
    const adminToken = await loginAdmin();
    const users = await request('/api/admin/users', { token: adminToken });
    const user = users.data.find((item) => item.email === userEmail);
    assert.ok(user);

    const add = await request(`/api/admin/users/${encodeURIComponent(user.id)}/adjustments`, {
      method: 'POST',
      token: adminToken,
      body: { operation: 'add', asset: 'USDC', amount: '25.500000000000000001', note: 'Test balance correction' },
    });
    assert.equal(add.status, 201);
    assert.equal(add.data.internalBalances.USDC, '25.500000000000000001');
    const overdraw = await request(`/api/admin/users/${encodeURIComponent(user.id)}/adjustments`, {
      method: 'POST',
      token: adminToken,
      body: { operation: 'withdraw', asset: 'USDC', amount: '30', note: 'Test overdraw' },
    });
    assert.equal(overdraw.status, 409);
    const debit = await request(`/api/admin/users/${encodeURIComponent(user.id)}/adjustments`, {
      method: 'POST',
      token: adminToken,
      body: { operation: 'withdraw', asset: 'USDC', amount: '5', note: 'Test manual debit' },
    });
    assert.equal(debit.status, 201);
    assert.equal(debit.data.internalBalances.USDC, '20.500000000000000001');
    assert.equal((await request('/api/wallet', { token: userToken })).data.internalBalances.USDC, '20.500000000000000001');

    const suspended = await request(`/api/admin/users/${encodeURIComponent(user.id)}/status`, {
      method: 'PATCH',
      token: adminToken,
      body: { status: 'Suspended' },
    });
    assert.equal(suspended.status, 200);
    assert.equal((await request('/api/wallet', { token: userToken })).status, 403);
    assert.equal((await request(`/api/admin/users/${encodeURIComponent(user.id)}/status`, { method: 'PATCH', token: adminToken, body: { status: 'Active' } })).status, 200);

    const deleted = await request(`/api/admin/users/${encodeURIComponent(user.id)}`, { method: 'DELETE', token: adminToken });
    assert.equal(deleted.status, 200);
    assert.equal(deleted.data.status, 'Deleted');
    assert.equal((await request('/api/wallet', { token: userToken })).status, 403);
    const preserved = (await request('/api/admin/users', { token: adminToken })).data.find((item) => item.id === user.id);
    assert.equal(preserved.email, userEmail);
    assert.equal(preserved.internalBalances.USDC, '20.500000000000000001');
    assert.equal((await request('/api/admin/requests', { token: adminToken })).data.some((item) => item.userId === user.id), true);

    const restored = await request(`/api/admin/users/${encodeURIComponent(user.id)}/restore`, { method: 'POST', token: adminToken });
    assert.equal(restored.status, 200);
    assert.equal(restored.data.status, 'Active');
    assert.equal((await request('/api/wallet', { token: userToken })).status, 200);

    const database = new DatabaseSync(databasePath);

    const admin = database.prepare('SELECT id, role, status FROM users WHERE lower(email) = ?').get(adminEmail);
    const audit = database.prepare("SELECT COUNT(*) AS count FROM admin_user_audit WHERE user_id = ? AND action IN ('deleted', 'restored')").get(user.id);
    const ledger = database.prepare('SELECT COUNT(*) AS count FROM internal_ledger WHERE user_id = ? AND admin_id = ?').get(user.id, (await request('/api/admin/users', { token: adminToken })).data.find((item) => item.role === 'Admin').id);
    database.close();
    assert.equal(audit.count, 2);
    assert.equal(ledger.count, 2);
    const adminUser = (await request('/api/admin/users', { token: adminToken })).data.find((item) => item.role === 'Admin');
    assert.equal((await request(`/api/admin/users/${encodeURIComponent(adminUser.id)}`, { method: 'DELETE', token: adminToken })).status, 403);
  });

  it('rejects invalid Google credentials and credentials issued for another audience', async () => {
    for (const credential of ['invalid-google-token', 'wrong-audience-google-token']) {
      const response = await request('/auth/google', { method: 'POST', body: { credential } });
      assert.equal(response.status, 401, `${credential} must be rejected`);
      assert.equal(response.data.requiresOtp, undefined);
      assert.ok(response.data.error);
    }
  });

  it('creates an OTP challenge after Google verification without email delivery', async () => {
    const response = await request('/auth/google', {
      method: 'POST',
      body: { credential: 'verified-google-token' },
    });

    assert.equal(response.status, 200);
    assert.equal(response.data.requiresOtp, true);
    assert.equal(response.data.email, 'google-otp-user@example.test');
    assert.equal(response.data.mailConfigured, false);
    assert.match(response.data.devCode, /^\d{6}$/);
    assert.ok(response.data.challengeId);

    const database = new DatabaseSync(databasePath);

    const admin = database.prepare('SELECT id, role, status FROM users WHERE lower(email) = ?').get(adminEmail);
    try {
      const challenge = database.prepare('SELECT email, consumed FROM otp_challenges WHERE id = ?').get(response.data.challengeId);
      assert.equal(challenge.email, response.data.email);
      assert.equal(challenge.consumed, 0);
    } finally {
      database.close();
    }
  });

  it('rejects an expired OTP without creating an account or session', async () => {
    const email = 'expired-otp-user@example.test';
    const registration = await registerWithTestOtp(email);
    const database = new DatabaseSync(databasePath);

    const admin = database.prepare('SELECT id, role, status FROM users WHERE lower(email) = ?').get(adminEmail);
    database.prepare('UPDATE otp_challenges SET expires_at = ? WHERE id = ?').run(Date.now() - 1, registration.challengeId);
    database.close();

    const verification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: registration.challengeId, code: registration.devCode },
    });
    assert.equal(verification.status, 401);
    assert.equal(verification.data.token, undefined);

    const verificationDb = new DatabaseSync(databasePath);
    assert.equal(verificationDb.prepare('SELECT id FROM users WHERE email = ?').get('expired-otp-user@example.test'), undefined);
    verificationDb.close();
  });

  it('rejects correct OTPs after the maximum number of incorrect attempts', async () => {
    const email = 'locked-otp-user@example.test';
    const registration = await registerWithTestOtp(email);
    const incorrectCode = registration.devCode === '999999' ? '000000' : '999999';

    for (let attempt = 0; attempt < 5; attempt += 1) {
      const failedVerification = await request('/auth/verify-otp', {
        method: 'POST',
        body: { challengeId: registration.challengeId, code: incorrectCode },
      });
      assert.equal(failedVerification.status, 401, `Incorrect attempt ${attempt + 1} must fail`);
    }

    const lockedVerification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: registration.challengeId, code: registration.devCode },
    });
    assert.equal(lockedVerification.status, 401);
    assert.equal(lockedVerification.data.token, undefined);

    const verificationDb = new DatabaseSync(databasePath);
    assert.equal(verificationDb.prepare('SELECT id FROM users WHERE email = ?').get(email), undefined);
    verificationDb.close();
  });

  it('rejects replayed OTPs after a returning user signs in', async () => {
    const email = 'returning-otp-user@example.test';
    const registration = await registerWithTestOtp(email);
    const registrationVerification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: registration.challengeId, code: registration.devCode },
    });
    assert.equal(registrationVerification.status, 200);
    assert.equal(registrationVerification.data.pendingApproval, true);

    const activationDb = new DatabaseSync(databasePath);
    try {
      activationDb.prepare('UPDATE users SET status = ? WHERE email = ?').run('Active', email);
    } finally {
      activationDb.close();
    }

    const login = await request('/auth/login', {
      method: 'POST',
      body: { email, password: userPassword },
    });
    assert.equal(login.status, 200);
    assert.equal(login.data.requiresOtp, true);
    assert.equal(login.data.mailConfigured, false);
    assert.match(login.data.devCode, /^\d{6}$/);

    const verificationBody = { challengeId: login.data.challengeId, code: login.data.devCode };
    const verification = await request('/auth/verify-otp', { method: 'POST', body: verificationBody });
    assert.equal(verification.status, 200);
    assert.equal(verification.data.user.email, email);
    assert.equal(typeof verification.data.token, 'string');
    const session = await request('/api/wallet', { token: verification.data.token });
    assert.equal(session.status, 200);
    assert.equal(session.data.user.email, email);

    const replay = await request('/auth/verify-otp', { method: 'POST', body: verificationBody });
    assert.equal(replay.status, 401);
    assert.equal(replay.data.token, undefined);
  });

  it('replaces older login and registration OTPs without crossing their purposes', async () => {
    const registrationEmail = 'otp-registration-replacement@example.test';
    const firstRegistration = await registerWithTestOtp(registrationEmail);
    const latestRegistration = await registerWithTestOtp(registrationEmail);

    const oldRegistrationVerification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: firstRegistration.challengeId, code: firstRegistration.devCode },
    });
    assert.equal(oldRegistrationVerification.status, 401);

    const latestRegistrationVerification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: latestRegistration.challengeId, code: latestRegistration.devCode },
    });
    assert.equal(latestRegistrationVerification.status, 200);
    assert.equal(latestRegistrationVerification.data.pendingApproval, true);

    const registrationUserDb = new DatabaseSync(databasePath);
    registrationUserDb.prepare('UPDATE users SET status = ? WHERE email = ?').run('Active', registrationEmail);
    registrationUserDb.close();

    const loginRequest = () => request('/auth/login', {
      method: 'POST',
      body: { email: registrationEmail, password: userPassword },
    });
    const firstLogin = await loginRequest();
    const latestLogin = await loginRequest();
    assert.equal(firstLogin.status, 200);
    assert.equal(latestLogin.status, 200);

    const oldLoginVerification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: firstLogin.data.challengeId, code: firstLogin.data.devCode },
    });
    assert.equal(oldLoginVerification.status, 401);

    const latestLoginVerification = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: latestLogin.data.challengeId, code: latestLogin.data.devCode },
    });
    assert.equal(latestLoginVerification.status, 200);

    const isolationEmail = 'otp-purpose-isolation@example.test';
    const setupDb = new DatabaseSync(databasePath);
    const admin = setupDb.prepare('SELECT password_hash FROM users WHERE lower(email) = ?').get(adminEmail);
    setupDb.prepare('INSERT INTO users (id, name, email, password_hash, role, status, joined) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
      'otp-purpose-isolation-user',
      'OTP Isolation User',
      isolationEmail,
      admin.password_hash,
      'User',
      'Active',
      '2026-09-25',
    );
    setupDb.close();

    const firstIsolationLogin = await request('/auth/login', {
      method: 'POST',
      body: { email: isolationEmail, password: adminPassword },
    });
    assert.equal(firstIsolationLogin.status, 200);

    const deleteIsolationUserDb = new DatabaseSync(databasePath);
    deleteIsolationUserDb.prepare('DELETE FROM users WHERE email = ?').run(isolationEmail);
    deleteIsolationUserDb.close();

    const isolationRegistration = await registerWithTestOtp(isolationEmail);
    const afterRegistrationDb = new DatabaseSync(databasePath);
    assert.equal(
      afterRegistrationDb.prepare('SELECT consumed FROM otp_challenges WHERE id = ?').get(firstIsolationLogin.data.challengeId).consumed,
      0,
      'A registration challenge must not invalidate a pending login challenge for the same email',
    );
    const isolationAdmin = afterRegistrationDb.prepare('SELECT password_hash FROM users WHERE lower(email) = ?').get(adminEmail);
    afterRegistrationDb.prepare('INSERT INTO users (id, name, email, password_hash, role, status, joined) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
      'otp-purpose-isolation-user',
      'OTP Isolation User',
      isolationEmail,
      isolationAdmin.password_hash,
      'User',
      'Active',
      '2026-09-25',
    );
    afterRegistrationDb.close();

    const secondIsolationLogin = await request('/auth/login', {
      method: 'POST',
      body: { email: isolationEmail, password: adminPassword },
    });
    assert.equal(secondIsolationLogin.status, 200);

    const afterSecondLoginDb = new DatabaseSync(databasePath);
    assert.equal(afterSecondLoginDb.prepare('SELECT consumed FROM otp_challenges WHERE id = ?').get(isolationRegistration.challengeId).consumed, 0);
    afterSecondLoginDb.close();

    const replacedIsolationLogin = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: firstIsolationLogin.data.challengeId, code: firstIsolationLogin.data.devCode },
    });
    assert.equal(replacedIsolationLogin.status, 401);

    const validIsolationLogin = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: secondIsolationLogin.data.challengeId, code: secondIsolationLogin.data.devCode },
    });
    assert.equal(validIsolationLogin.status, 200);

    const removeIsolationUserDb = new DatabaseSync(databasePath);
    removeIsolationUserDb.prepare('DELETE FROM users WHERE email = ?').run(isolationEmail);
    removeIsolationUserDb.close();

    const validIsolationRegistration = await request('/auth/verify-otp', {
      method: 'POST',
      body: { challengeId: isolationRegistration.challengeId, code: isolationRegistration.devCode },
    });
    assert.equal(validIsolationRegistration.status, 200);
    assert.equal(validIsolationRegistration.data.pendingApproval, true);
  });

  it('denies registered users admin reads and updates without changing protected data', async () => {
    assert.ok(userToken, 'The registered user session must be available.');
    for (const pathname of ['/api/admin/overview', '/api/admin/custody-readiness', '/api/admin/users', '/api/admin/transactions']) {
      const response = await request(pathname, { token: userToken });
      assert.equal(response.status, 401, `${pathname} must reject a regular user session`);
    }

    const adminToken = await loginAdmin();
    const originalSettings = {
      maintenance: true,
      defaultNetwork: 'Preserved Network',
      supportEmail: 'preserved@example.test',
    };
    const settingsSetup = await request('/api/admin/settings', {
      method: 'PATCH',
      token: adminToken,
      body: originalSettings,
    });
    assert.equal(settingsSetup.status, 200);

    const settingsAttempt = await request('/api/admin/settings', {
      method: 'PATCH',
      token: userToken,
      body: { maintenance: true, defaultNetwork: 'Unauthorized Network', supportEmail: 'attacker@example.test' },
    });
    assert.equal(settingsAttempt.status, 401);

    const transactionAttempt = await request('/api/admin/transactions/TX-ADMIN-AUTH-TEST', {
      method: 'PATCH',
      token: userToken,
      body: { status: 'Rejected' },
    });
    assert.equal(transactionAttempt.status, 401);

    const overview = await request('/api/admin/overview', { token: adminToken });
    assert.equal(overview.status, 200);
    assert.deepEqual(overview.data.settings, originalSettings);
    const transactions = await request('/api/admin/transactions', { token: adminToken });
    assert.equal(transactions.status, 200);
    assert.equal(transactions.data.find(({ id }) => id === 'TX-ADMIN-AUTH-TEST')?.status, 'Pending');
  });

  it('rejects incomplete or malformed settings without changing saved values', async () => {
    const token = await loginAdmin();
    const originalSettings = {
      maintenance: true,
      defaultNetwork: 'Preserved Network',
      supportEmail: 'preserved@example.test',
    };
    const setup = await request('/api/admin/settings', {
      method: 'PATCH',
      token,
      body: originalSettings,
    });
    assert.equal(setup.status, 200);
    assert.deepEqual(setup.data, originalSettings);

    const invalidPayloads = [
      undefined,
      null,
      [],
      { maintenance: false, defaultNetwork: 'Network' },
      { maintenance: 'false', defaultNetwork: 'Network', supportEmail: 'valid@example.test' },
      { maintenance: false, defaultNetwork: '  ', supportEmail: 'valid@example.test' },
      { maintenance: false, defaultNetwork: 'Network', supportEmail: 'not-an-email' },
      { maintenance: false, defaultNetwork: 'Network', supportEmail: 'valid@example.test', extra: 'unexpected' },
    ];
    for (const body of invalidPayloads) {
      const response = await request('/api/admin/settings', { method: 'PATCH', token, body });
      assert.equal(response.status, 400, `Invalid payload should be rejected: ${JSON.stringify(body)}`);
      assert.match(response.data.error, /settings|maintenance|network|email|json/i);
    const overview = await request('/api/admin/overview', { token });
      assert.deepEqual(overview.data.settings, originalSettings);
    }

    const malformedJson = await fetch(`${baseUrl}/api/admin/settings`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: '{"maintenance":',
    });
    assert.equal(malformedJson.status, 400);
    assert.match((await malformedJson.json()).error, /valid JSON/i);
    const overview = await request('/api/admin/overview', { token });
    assert.deepEqual(overview.data.settings, originalSettings);
  });

  it('logs in the test admin and reads and updates protected settings and transactions', async () => {
    const badLogin = await request('/admin/login', {
      method: 'POST',
      body: { identifier: 'arcwallet@admin', password: 'incorrect-test-password' },
    });
    assert.equal(badLogin.status, 401);

    const token = await loginAdmin();

    const overview = await request('/api/admin/overview', { token });
    assert.equal(overview.status, 200);
    assert.ok(overview.data.metrics);
    const users = await request('/api/admin/users', { token });
    assert.equal(users.status, 200);
    assert.ok(Array.isArray(users.data));
    const transactions = await request('/api/admin/transactions', { token });
    assert.equal(transactions.status, 200);
    assert.equal(transactions.data.find(({ id }) => id === 'TX-ADMIN-AUTH-TEST')?.status, 'Pending');

    const settings = await request('/api/admin/settings', {
      method: 'PATCH',
      token,
      body: { maintenance: true, defaultNetwork: 'Test Network', supportEmail: 'ops@example.test' },
    });
    assert.equal(settings.status, 200);
    assert.deepEqual(settings.data, {
      maintenance: true,
      defaultNetwork: 'Test Network',
      supportEmail: 'ops@example.test',
    });

    const update = await request('/api/admin/transactions/unknown', {
      method: 'PATCH',
      token,
      body: { status: 'Success' },
    });
    assert.equal(update.status, 404);

    const successfulUpdate = await request('/api/admin/transactions/TX-ADMIN-AUTH-TEST', {
      method: 'PATCH',
      token,
      body: { status: 'Success' },
    });
    assert.equal(successfulUpdate.status, 200);
    assert.equal(successfulUpdate.data.status, 'Success');

    const invalidStatus = await request('/api/admin/transactions/unknown', {
      method: 'PATCH',
      token,
      body: { status: 'Unknown' },
    });
    assert.equal(invalidStatus.status, 400);
  });
});
