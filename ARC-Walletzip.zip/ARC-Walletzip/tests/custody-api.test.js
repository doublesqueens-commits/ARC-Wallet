const assert = require('node:assert/strict');
const { spawn, spawnSync } = require('node:child_process');
const { once } = require('node:events');
const fs = require('node:fs');
const http = require('node:http');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { after, before, describe, it } = require('node:test');

const root = path.resolve(__dirname, '..');
const custodyToken = 'custody-test-token';
const adminEmail = 'custody-admin@example.test';
const adminPassword = 'custody-admin-password-2026';
const state = {
  healthy: true,
  mismatchedAddressCustomer: false,
  mismatchedBalanceCustomer: false,
  forcedAddress: '',
  addressCounter: 0,
  addressRequests: [],
  balanceRequests: [],
  payoutRequests: [],
  payoutTransfers: new Map(),
  loseNextPayoutResponse: false,
  misreportNextPayoutRecipient: false,
  balances: new Map(),
  capabilities: {
    status: 'verified',
    pairs: [{ asset: 'ETH', network: 'Ethereum Mainnet' }],
  },
};
let tempDir;
let databasePath;
let providerServer;
let appProcess;
let providerUrl;
let baseUrl;
let providerPort;
let adminToken;

const json = (response, status, payload) => {
  response.writeHead(status, { 'Content-Type': 'application/json' });
  response.end(JSON.stringify(payload));
};

const getFreePort = async () => {
  const listener = net.createServer();
  listener.listen(0, '127.0.0.1');
  await once(listener, 'listening');
  const { port } = listener.address();
  await new Promise((resolve, reject) => listener.close((error) => error ? reject(error) : resolve()));
  return port;
};

const startProvider = async () => {
  providerServer = http.createServer(async (request, response) => {
    const url = new URL(request.url, `http://${request.headers.host}`);
    if (request.headers.authorization !== `Bearer ${custodyToken}`) {
      json(response, 401, { error: 'Unauthorized' });
      return;
    }
    if (request.method === 'GET' && url.pathname === '/health') {
      json(response, state.healthy ? 200 : 503, { status: state.healthy ? 'ok' : 'unavailable', provider: 'Test Custody' });
      return;
    }
    if (request.method === 'GET' && url.pathname === '/v1/capabilities') {
      json(response, 200, state.capabilities);
      return;
    }
    if (request.method === 'POST' && url.pathname === '/v1/deposit-addresses') {
      let body = '';
      for await (const chunk of request) body += chunk;
      const input = JSON.parse(body || '{}');
      state.addressRequests.push(input);
      state.addressCounter += 1;
      const address = state.forcedAddress || `0x${state.addressCounter.toString(16).padStart(40, '0')}`;
      json(response, 200, {
        status: 'verified',
        customerId: state.mismatchedAddressCustomer ? 'other-customer' : input.customerId,
        asset: input.asset,
        network: input.network,
        address,
      });
      return;
    }
    if (request.method === 'GET' && url.pathname === '/v1/balances') {
      const input = Object.fromEntries(url.searchParams);
      state.balanceRequests.push(input);
      const key = `${input.customerId}:${input.asset}:${input.network}`;
      json(response, 200, {
        status: 'verified',
        customerId: state.mismatchedBalanceCustomer ? 'other-customer' : input.customerId,
        asset: input.asset,
        network: input.network,
        address: input.address,
        confirmedBalance: state.balances.get(key) || '0',
      });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/v1/payouts') {
      let body = '';
      for await (const chunk of request) body += chunk;
      const input = JSON.parse(body || '{}');
      state.payoutRequests.push(input);
      let transfer = state.payoutTransfers.get(input.requestId);
      if (!transfer) {
        transfer = {
          status: 'completed',
          requestId: input.requestId,
          customerId: input.customerId,
          asset: input.asset,
          network: input.network,
          amount: input.amount,
          recipient: input.recipient,
          transactionReference: `0x${state.payoutTransfers.size.toString(16).padStart(64, '0')}`,
        };
        state.payoutTransfers.set(input.requestId, transfer);
      }
      if (state.loseNextPayoutResponse) {
        state.loseNextPayoutResponse = false;
        json(response, 503, { error: 'Provider accepted the transfer but confirmation response was lost.' });
        return;
      }
      if (state.misreportNextPayoutRecipient) {
        state.misreportNextPayoutRecipient = false;
        json(response, 200, { ...transfer, recipient: '0x9999999999999999999999999999999999999999' });
        return;
      }
      json(response, 200, transfer);
      return;
    }
    json(response, 404, { error: 'Not found' });
  });
  providerPort = await getFreePort();
  providerUrl = `http://127.0.0.1:${providerPort}`;
  providerServer.listen(providerPort, '127.0.0.1');
  await once(providerServer, 'listening');
};

const startApp = async () => {
  const port = await getFreePort();
  baseUrl = `http://127.0.0.1:${port}`;
  appProcess = spawn(process.execPath, [path.join(root, 'server.js')], {
    cwd: root,
    env: {
      ...process.env,
      NODE_ENV: 'test',
      DATABASE_PATH: databasePath,
      PORT: String(port),
      JWT_SECRET: 'isolated-custody-test-session-secret',
      ALLOW_DEV_OTP: 'true',
      ADMIN_EMAIL: adminEmail,
      ADMIN_PASSWORD: adminPassword,
      CUSTODY_API_BASE_URL: providerUrl,
      CUSTODY_API_TOKEN: custodyToken,
      CUSTODY_API_HEALTH_PATH: '/health',
      CUSTODY_API_CAPABILITIES_PATH: '/v1/capabilities',
      CUSTODY_API_ADDRESS_PATH: '/v1/deposit-addresses',
      CUSTODY_API_BALANCE_PATH: '/v1/balances',
      CUSTODY_API_PAYOUT_PATH: '/v1/payouts',
    },
    stdio: 'ignore',
  });
  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    if (appProcess.exitCode !== null) throw new Error('ARC server exited before becoming ready.');
    try {
      const response = await fetch(`${baseUrl}/api/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error('ARC server did not become ready.');
};

const stopApp = async () => {
  if (!appProcess || appProcess.exitCode !== null) return;
  const child = appProcess;
  const exited = once(child, 'exit');
  child.kill('SIGTERM');
  await Promise.race([exited, new Promise((resolve) => setTimeout(resolve, 3000))]);
  if (child.exitCode === null) {
    child.kill('SIGKILL');
    await exited;
  }
  appProcess = undefined;
};

const request = async (pathname, { method = 'GET', token, body } = {}) => {
  const response = await fetch(`${baseUrl}${pathname}`, {
    method,
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  return { status: response.status, data: await response.json() };
};

const register = async (email) => {
  const registration = await request('/auth/register', { method: 'POST', body: { email, password: 'test-custody-password-2026' } });
  assert.equal(registration.status, 200);
  const verification = await request('/auth/verify-otp', {
    method: 'POST',
    body: { challengeId: registration.data.challengeId, code: registration.data.devCode },
  });
  assert.equal(verification.status, 200);
  assert.equal(verification.data.pendingApproval, true);
  const approval = await request(`/api/admin/users/${encodeURIComponent(verification.data.user.id)}/approve`, { method: 'POST', token: adminToken });
  assert.equal(approval.status, 200);
  const login = await request('/auth/login', { method: 'POST', body: { email, password: 'test-custody-password-2026' } });
  assert.equal(login.status, 200);
  const activeSession = await request('/auth/verify-otp', {
    method: 'POST',
    body: { challengeId: login.data.challengeId, code: login.data.devCode },
  });
  assert.equal(activeSession.status, 200);
  return activeSession.data;
};

const receive = (token, asset = 'ETH', network = 'Ethereum Mainnet') => {
  const query = new URLSearchParams({ network });
  return request(`/api/wallet/receive/${asset}?${query}`, { token });
};

const balance = (token, asset = 'ETH', network = 'Ethereum Mainnet') => {
  const query = new URLSearchParams({ asset, network });
  return request(`/api/wallet/balance?${query}`, { token });
};

describe('customer-scoped custody API', () => {
  before(async () => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'arc-wallet-custody-tests-'));
    databasePath = path.join(tempDir, 'test.sqlite');
    await startProvider();
    await startApp();
    await stopApp();
    const setup = spawnSync(process.execPath, [path.join(root, 'scripts/setup-admin.js')], {
      cwd: root,
      env: { ...process.env, NODE_ENV: 'test', DATABASE_PATH: databasePath, ADMIN_EMAIL: adminEmail, ADMIN_PASSWORD: adminPassword },
      encoding: 'utf8',
      timeout: 10000,
    });
    assert.equal(setup.status, 0, `Admin setup failed.\n${setup.stdout}\n${setup.stderr}`);
    await startApp();
    const login = await request('/admin/login', { method: 'POST', body: { identifier: adminEmail, password: adminPassword } });
    assert.equal(login.status, 200);
    adminToken = login.data.token;
  });

  after(async () => {
    await stopApp();
    if (providerServer?.listening) await new Promise((resolve) => providerServer.close(resolve));
    if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
  });

  it('issues and reuses a provider-verified address unique to each customer', async () => {
    const first = await register('custody-first@example.test');
    const second = await register('custody-second@example.test');
    const firstAddress = await receive(first.token);
    const repeatedAddress = await receive(first.token);
    const secondAddress = await receive(second.token);

    assert.equal(firstAddress.status, 200);
    assert.equal(firstAddress.data.verified, true);
    assert.equal(firstAddress.data.provider, 'Test Custody');
    assert.equal(firstAddress.data.address, repeatedAddress.data.address);
    assert.notEqual(firstAddress.data.address, secondAddress.data.address);
    assert.deepEqual(state.addressRequests.map(({ customerId }) => customerId), [first.user.id, second.user.id]);
    assert.ok(state.addressRequests.every(({ asset, network }) => asset === 'ETH' && network === 'Ethereum Mainnet'));
  });

  it('returns only verified custody pairs and rejects unsupported pairs on every wallet endpoint', async () => {
    const account = await register('custody-capabilities@example.test');
    state.capabilities = {
      status: 'verified',
      pairs: [{ asset: 'ETH', network: 'Ethereum Mainnet' }],
    };

    const capabilities = await request('/api/wallet/capabilities', { token: account.token });
    assert.equal(capabilities.status, 200);
    assert.equal(capabilities.data.verified, true);
    assert.equal(capabilities.data.provider, 'Test Custody');
    assert.deepEqual(capabilities.data.pairs, [{ asset: 'ETH', network: 'Ethereum Mainnet' }]);

    const addressesBefore = state.addressRequests.length;
    assert.equal((await receive(account.token, 'ETH', 'Arbitrum')).status, 400);
    assert.equal((await balance(account.token, 'ETH', 'Arbitrum')).status, 400);
    assert.equal(state.addressRequests.length, addressesBefore);

    const rejectedClaim = await request('/api/wallet/deposit-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Arbitrum', amount: '1', txHash: `0x${'b'.repeat(64)}` },
    });
    assert.equal(rejectedClaim.status, 400);
    const rejectedWithdrawal = await request('/api/wallet/withdrawal-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Arbitrum', amount: '1', recipient: '0x1234567890abcdef1234567890abcdef12345678' },
    });
    assert.equal(rejectedWithdrawal.status, 400);

    state.capabilities = { status: 'unverified', pairs: [{ asset: 'ETH', network: 'Ethereum Mainnet' }] };
    assert.equal((await request('/api/wallet/capabilities', { token: account.token })).status, 503);
    assert.equal((await receive(account.token)).status, 503);
    state.capabilities = {
      status: 'verified',
      pairs: [{ asset: 'ETH', network: 'Ethereum Mainnet' }],
    };
  });

  it('shows private, sanitized custody readiness without enabling receiving', async () => {
    const account = await register('custody-readiness@example.test');
    state.healthy = true;
    const verified = await request('/api/admin/custody-readiness', { token: adminToken });
    assert.equal(verified.status, 200);
    assert.deepEqual(Object.keys(verified.data).sort(), ['checkedAt', 'configured', 'status']);
    assert.equal(verified.data.configured, true);
    assert.equal(verified.data.status, 'verified');
    assert.doesNotThrow(() => new Date(verified.data.checkedAt).toISOString());
    assert.equal(JSON.stringify(verified.data).includes(custodyToken), false);
    assert.equal(JSON.stringify(verified.data).includes('Test Custody'), false);
    assert.equal((await request('/api/admin/custody-readiness', { token: account.token })).status, 401);

    state.healthy = false;
    const failed = await request('/api/admin/custody-readiness', { token: adminToken });
    assert.equal(failed.status, 200);
    assert.deepEqual(failed.data.configured, true);
    assert.equal(failed.data.status, 'verification_failed');
    const unavailable = await receive(account.token);
    assert.equal(unavailable.status, 503);
    assert.equal(unavailable.data.address, undefined);
    state.healthy = true;
  });

  it('returns only provider-confirmed balances bound to the matching customer and address', async () => {
    const first = await register('custody-balance-first@example.test');
    const second = await register('custody-balance-second@example.test');
    const firstAddress = await receive(first.token);
    const secondAddress = await receive(second.token);
    state.balances.set(`${first.user.id}:ETH:Ethereum Mainnet`, '1.125');
    state.balances.set(`${second.user.id}:ETH:Ethereum Mainnet`, '9.75');

    const firstBalance = await balance(first.token);
    const secondBalance = await balance(second.token);
    assert.equal(firstBalance.status, 200);
    assert.equal(firstBalance.data.balance, '1.125');
    assert.equal(secondBalance.data.balance, '9.75');
    assert.notEqual(firstBalance.data.balance, secondBalance.data.balance);
    assert.equal(state.balanceRequests.at(-2).address, firstAddress.data.address);
    assert.equal(state.balanceRequests.at(-1).address, secondAddress.data.address);
  });

  it('keeps receiving and balances unavailable when provider verification or identity checks fail', async () => {
    const account = await register('custody-failure@example.test');
    state.healthy = false;
    const providerDown = await receive(account.token);
    assert.equal(providerDown.status, 503);
    assert.equal(providerDown.data.address, undefined);

    state.healthy = true;
    state.mismatchedAddressCustomer = true;
    const wrongAddressOwner = await receive(account.token);
    assert.equal(wrongAddressOwner.status, 503);
    assert.equal(wrongAddressOwner.data.address, undefined);
    state.mismatchedAddressCustomer = false;

    const issued = await receive(account.token);
    assert.equal(issued.status, 200);
    state.mismatchedBalanceCustomer = true;
    const wrongBalanceOwner = await balance(account.token);
    assert.equal(wrongBalanceOwner.status, 503);
    assert.equal(wrongBalanceOwner.data.balance, undefined);
    state.mismatchedBalanceCustomer = false;
  });

  it('rejects a provider address already assigned to another customer', async () => {
    const first = await register('custody-address-owner@example.test');
    const second = await register('custody-address-duplicate@example.test');
    const existing = await receive(first.token);
    state.forcedAddress = existing.data.address;
    const duplicate = await receive(second.token);
    state.forcedAddress = '';
    assert.equal(duplicate.status, 503);
    assert.equal(duplicate.data.address, undefined);
  });

  it('requires a separate confirmed payout after approval and safely reuses the same provider request on retry', async () => {
    const account = await register('custody-financial-requests@example.test');
    const address = await receive(account.token, 'ETH', 'Ethereum Mainnet');
    assert.equal(address.status, 200);

    const txHash = `0x${'a'.repeat(64)}`;
    const claim = await request('/api/wallet/deposit-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Ethereum Mainnet', amount: '1.250000000000000001', txHash },
    });
    assert.equal(claim.status, 201);
    assert.equal(claim.data.status, 'Pending');
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, undefined);
    const duplicate = await request('/api/wallet/deposit-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Ethereum Mainnet', amount: '1.250000000000000001', txHash },
    });
    assert.equal(duplicate.status, 409);

    const claimReview = await request(`/api/admin/requests/${claim.data.id}/review`, { method: 'POST', token: adminToken, body: { decision: 'approve' } });
    assert.equal(claimReview.status, 200);
    assert.equal(claimReview.data.status, 'Approved');
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '1.250000000000000001');
    state.balances.set(`${account.user.id}:ETH:Ethereum Mainnet`, '8.5');
    assert.equal((await balance(account.token)).data.balance, '8.5');
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '1.250000000000000001');

    const withdrawal = await request('/api/wallet/withdrawal-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Ethereum Mainnet', amount: '0.4', recipient: '0x1234567890abcdef1234567890abcdef12345678' },
    });
    assert.equal(withdrawal.status, 201);
    assert.equal(withdrawal.data.status, 'Pending');
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '1.250000000000000001');
    assert.equal((await request(`/api/admin/requests/${withdrawal.data.id}/settle`, { method: 'POST', token: adminToken })).status, 409);
    assert.equal(state.payoutRequests.length, 0, 'pending withdrawals must not be sent to the provider');
    const excessive = await request('/api/wallet/withdrawal-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Ethereum Mainnet', amount: '0.9', recipient: '0x1234567890abcdef1234567890abcdef12345678' },
    });
    assert.equal(excessive.status, 409);

    const withdrawalReview = await request(`/api/admin/requests/${withdrawal.data.id}/review`, { method: 'POST', token: adminToken, body: { decision: 'approve' } });
    assert.equal(withdrawalReview.status, 200);
    assert.equal(withdrawalReview.data.status, 'Approved');
    assert.equal(withdrawalReview.data.payoutStatus, 'Awaiting payout');
    assert.equal(state.payoutRequests.length, 0, 'approval must not initiate a payout');
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '0.850000000000000001');
    let walletRequests = await request('/api/wallet/requests', { token: account.token });
    assert.equal(walletRequests.data.requests.find((item) => item.id === withdrawal.data.id).payoutStatus, 'Awaiting payout');
    assert.equal((await balance(account.token)).data.balance, '8.5');
    assert.equal((await request(`/api/admin/requests/${withdrawal.data.id}/review`, { method: 'POST', token: adminToken, body: { decision: 'approve' } })).status, 409);

    state.loseNextPayoutResponse = true;
    const uncertainPayout = await request(`/api/admin/requests/${withdrawal.data.id}/settle`, { method: 'POST', token: adminToken });
    assert.equal(uncertainPayout.status, 503);
    assert.equal(uncertainPayout.data.request.payoutStatus, 'Failed');
    assert.match(uncertainPayout.data.request.payoutError, /rejected|could not verify|could not be reached/i);
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '0.850000000000000001');
    walletRequests = await request('/api/wallet/requests', { token: account.token });
    assert.equal(walletRequests.data.requests.find((item) => item.id === withdrawal.data.id).payoutStatus, 'Failed');

    const retry = await request(`/api/admin/requests/${withdrawal.data.id}/settle`, { method: 'POST', token: adminToken });
    assert.equal(retry.status, 200);
    assert.equal(retry.data.payoutStatus, 'Completed');
    assert.match(retry.data.payoutReference, /^0x[0-9a-f]{64}$/);
    assert.deepEqual(state.payoutRequests.map((item) => item.requestId), [withdrawal.data.id, withdrawal.data.id]);
    assert.equal(state.payoutTransfers.size, 1, 'provider idempotency must result in only one transfer');
    assert.equal(state.payoutRequests[0].customerId, account.user.id);
    assert.equal(state.payoutRequests[0].asset, 'ETH');
    assert.equal(state.payoutRequests[0].network, 'Ethereum Mainnet');
    assert.equal(state.payoutRequests[0].amount, '0.4');
    assert.equal(state.payoutRequests[0].recipient, '0x1234567890abcdef1234567890abcdef12345678');
    const payoutRequestCount = state.payoutRequests.length;
    const repeatedSettlement = await request(`/api/admin/requests/${withdrawal.data.id}/settle`, { method: 'POST', token: adminToken });
    assert.equal(repeatedSettlement.status, 200);
    assert.equal(repeatedSettlement.data.payoutStatus, 'Completed');
    assert.equal(state.payoutRequests.length, payoutRequestCount, 'completed requests must not be sent to the provider again');
    walletRequests = await request('/api/wallet/requests', { token: account.token });
    const completedWithdrawal = walletRequests.data.requests.find((item) => item.id === withdrawal.data.id);
    assert.equal(completedWithdrawal.payoutStatus, 'Completed');
    assert.equal(completedWithdrawal.payoutReference, retry.data.payoutReference);
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '0.850000000000000001');

    const secondWithdrawal = await request('/api/wallet/withdrawal-requests', {
      method: 'POST',
      token: account.token,
      body: { asset: 'ETH', network: 'Ethereum Mainnet', amount: '0.1', recipient: '0xabcdefabcdefabcdefabcdefabcdefabcdefabcd' },
    });
    assert.equal(secondWithdrawal.status, 201);
    assert.equal((await request(`/api/admin/requests/${secondWithdrawal.data.id}/review`, { method: 'POST', token: adminToken, body: { decision: 'approve' } })).status, 200);
    state.misreportNextPayoutRecipient = true;
    const mismatchedConfirmation = await request(`/api/admin/requests/${secondWithdrawal.data.id}/settle`, { method: 'POST', token: adminToken });
    assert.equal(mismatchedConfirmation.status, 502);
    assert.equal(mismatchedConfirmation.data.request.payoutStatus, 'Failed');
    assert.equal(mismatchedConfirmation.data.request.payoutReference, null);
    const verifiedRetry = await request(`/api/admin/requests/${secondWithdrawal.data.id}/settle`, { method: 'POST', token: adminToken });
    assert.equal(verifiedRetry.status, 200);
    assert.equal(verifiedRetry.data.payoutStatus, 'Completed');
    assert.equal(state.payoutTransfers.size, 2, 'unverified responses and retries must not create an additional provider transfer');
    assert.equal((await request('/api/wallet', { token: account.token })).data.internalBalances.ETH, '0.750000000000000001');
  });
});