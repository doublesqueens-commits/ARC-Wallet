const crypto = require('node:crypto');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const password = String(process.env.ADMIN_PASSWORD || '');
if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 12) {
  console.error('Set ADMIN_EMAIL and an ADMIN_PASSWORD of at least 12 characters in Replit Secrets.');
  process.exit(1);
}

const database = new DatabaseSync(process.env.DATABASE_PATH || path.join(__dirname, '..', 'orbit.db'));
try { database.exec('ALTER TABLE users ADD COLUMN username TEXT'); } catch {}
database.exec('CREATE UNIQUE INDEX IF NOT EXISTS users_username_unique ON users(username) WHERE username IS NOT NULL');
const salt = crypto.randomBytes(16).toString('hex');
const passwordHash = `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`;
const user = database.prepare('SELECT id FROM users WHERE email = ?').get(email);
if (user) {
  database.prepare('UPDATE users SET role = ?, status = ?, password_hash = ?, username = ? WHERE id = ?').run('Admin', 'Active', passwordHash, 'arcwallet@admin', user.id);
} else {
  database.prepare('INSERT INTO users (id, name, email, username, password_hash, role, status, joined) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').run(`admin-${crypto.randomUUID()}`, email.split('@')[0], email, 'arcwallet@admin', passwordHash, 'Admin', 'Active', new Date().toISOString().slice(0, 10));
}
console.log('Admin access enabled. Open /admin and sign in as arcwallet@admin.');