---
name: Replit port mapping and environment changes
description: Shared environment updates may regenerate imported Replit configuration and discard separate port edits.
---

Treat shared environment-variable changes as potential updates to the generated Replit configuration. Preserve the intended port routing after such changes, rather than assuming independent config edits survive.

**Why:** An environment write restored an older port mapping even though the app itself stayed healthy. Configuration writes from different surfaces were not automatically merged.

**How to apply:** When changing environment variables and port routing in the same task, finalize the environment first and then confirm the persisted routing before completing the task.