---
name: Google OAuth preview origins
description: Distinguish browser origins and understand Google OAuth Testing behavior for sign-in-only apps.
---

Google Identity Services authorizes the browser page's exact JavaScript origin. Replit app-preview screenshots load the app from `http://127.0.0.1:5000`, while the user-facing preview uses its `https://*.replit.dev` origin. A rejected localhost origin in a screenshot does not prove the public preview is unauthorized.

For OAuth audience checks, Google's current policy distinguishes apps using only the basic identity scopes (`openid`, `email`, `profile`): external apps in Testing can still be accessed by accounts outside the test-user allowlist, but users see a testing warning. Do not assume that leaving Testing automatically blocks sign-in for a Sign in with Google-only app. Published status and brand/sensitive-scope verification are separate checks.

**Why:** During sign-in verification, the screenshot browser reported an origin rejection on localhost even after the actual Replit preview origin was added. Testing the public preview host showed the authorized Google button loading without the origin error. Google's Testing exception for basic identity scopes also changes whether non-test accounts are blocked.

**How to apply:** For Google OAuth checks, open the public Replit development origin in a browser and inspect the rendered GSI button and console errors. Check the audience status in Google Cloud separately from the app's requested scopes. After publication, retrieve the actual production URL and add that origin separately; do not infer it from the development domain.